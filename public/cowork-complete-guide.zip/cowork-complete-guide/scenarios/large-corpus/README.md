# Large Corpus Scenario

**Used in:** Lesson 7 - Research at Scale

## Purpose
50+ documents for demonstrating sub-agent parallel processing.

## Files Needed (50+ documents)
Can be generated or sourced:
- Industry articles (20+)
- Research summaries (15+)
- Meeting notes (10+)
- Misc documents (10+)

Content requirements:
- Should have overlapping themes that benefit from synthesis
- Large enough to feel substantial
- Diverse enough to show parallel processing value

Alternative: Could use public domain content (news articles, research abstracts) as placeholder content.
