# Receipts Scenario

**Used in:** Lesson 8 - Document Creation (Excel)

## Purpose
Receipt images/PDFs for demonstrating data extraction to Excel.

## Files Needed (15-20 receipts)
Mix of formats:
- Photos of paper receipts (8-10) - varying quality
- PDF receipts (5-7) - digital receipts
- Screenshot receipts (2-3) - online purchases

Content requirements:
- Clear dates, vendors, amounts
- Multiple categories (food, supplies, travel, subscriptions)
- Some recurring vendors (shows up multiple times)
- 1-2 unclear/hard-to-read receipts (tests the "flagged items" feature)
- Date range spanning 2-3 months
