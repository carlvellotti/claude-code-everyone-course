# Done Framework Scenario

**Used in:** Lesson 3 - The "Done" Framework

## Purpose
Files for practicing specific, detailed delegations. Should be organizeable multiple ways so the student's constraints actually matter.

## Files Needed (15-20 files)
Mix that could be organized by:
- Date (some files have dates, some don't)
- Project (files from 2-3 different projects)
- Type (documents, images, data)

Include some ambiguous files that could go multiple places - this teaches why constraints matter.
