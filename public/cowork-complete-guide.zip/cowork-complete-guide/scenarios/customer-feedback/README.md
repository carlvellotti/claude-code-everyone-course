# Customer Feedback Scenario

**Used in:** Lesson 6 - Research Synthesis

## Purpose
20 customer feedback documents for multi-document synthesis practice.

## Files Needed (20 documents)
Mix of feedback formats:
- Survey responses (5-7) - structured feedback
- Email complaints/praise (5-7) - unstructured
- Interview transcripts (3-5) - conversational
- Support ticket summaries (3-5) - brief, problem-focused

Content requirements:
- Some themes should repeat across documents
- Include 2-3 contradictions (Customer A loves X, Customer B hates X)
- Varying levels of detail
- Mix of positive, negative, and neutral feedback
- Common topic: a fictional product or service feature

Good fictional context: "Basecamp Coffee" loyalty program feedback
