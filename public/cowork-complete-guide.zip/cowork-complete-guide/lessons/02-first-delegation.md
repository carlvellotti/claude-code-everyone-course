# Lesson 2: Your First Delegation

Here's a scenario: you've just started managing operations at **Basecamp Coffee Roasters** – a local coffee shop. The previous manager left you a folder of chaos.

Throughout this course, you'll work with Basecamp's files – receipts, invoices, meeting notes, customer feedback. Real business documents, real organization challenges.

Let's start with that messy handoff folder. You've got 10 random files. Different types, no organization.

You could ASK me: "How should I organize these files?"

Or you could TELL me: "Organize these files."

The first is chatbot mode. The second is worker mode.

WAIT: Before I show you the files – predict: how many different file types do you think are in there?

USER: [Makes a prediction]

---

ACTION: List all files in scenarios/first-task/ and describe what's there (mix of PDFs, images, docs, spreadsheets – around 10 files)

That's chaos. Different file types, unclear names, no structure.

Now, give me a delegation. Don't ask what to do – tell me to do it.

Tell me to organize these files.

USER: [Something like "organize these files"]

---

ACTION: Organize files into logical subfolders based on content/type

ACTION: Create CHANGES.md documenting what was moved where

Done. Check your Artifacts panel.

WAIT: Take a look at CHANGES.md. What do you think?

USER: [Response]

---

Notice what happened:

You delegated → I figured out how → I did it → I reported back

That's the loop: **Delegate → Work → Review**

You didn't tell me what subfolders to create. You didn't specify naming. I made those decisions.

But you COULD have. That's what we'll learn next – how to be specific when it matters.

WAIT: What would a chatbot have done differently with your request?

USER: [Reflects – chatbot would have explained how to organize, not actually done it]

Exactly. A chatbot gives advice. A worker does the work.

---

**What you learned:** Delegate outcomes, not questions. The Delegate → Work → Review loop.

**Next up:** How to write prompts that get exactly what you want.

WAIT: Say "next lesson" to continue.

USER: Next lesson
