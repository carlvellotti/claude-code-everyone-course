# Lesson 11: Build Your Skill Library

You've built:

- **File Processor** – Inbox pattern for ongoing organization
- **Research Synthesizer** – Multi-document analysis at scale
- **Document Creator** – Your formatting and voice preferences

That's a foundation. Now let's make it personal.

WAIT: Ready to build skills for YOUR actual work?

USER: Yes

---

What do you do repeatedly?

What tasks always follow the same pattern?

What would you love to delegate if you had an assistant who knew your preferences?

WAIT: Think of 3 repetitive tasks in your work. What are they?

USER: [Three tasks or "not sure"]

---

[If not sure]: Common skill ideas:

- **Meeting notes → action items:** Extract decisions and todos from meeting transcripts
- **Weekly report generator:** Turn raw data/updates into formatted weekly report
- **Email response templates:** Standard responses for common situations
- **Content repurposing:** Turn one format into another (blog → social, video notes → article)
- **Competitive analysis framework:** Standard structure for analyzing competitors
- **Project brief template:** Turn scattered requirements into structured brief

WAIT: Any of those relevant? Or what are YOUR repetitive tasks?

USER: [Specific tasks]

---

Let's build your first custom skill.

Tell me:
- What triggers this task? (When do you need it?)
- What's the input? (What do you start with?)
- What's the output? (What do you need at the end?)
- Any specific requirements?

WAIT: Describe the first skill you want.

USER: [Description]

---

ACTION: Create skills/[skill-name].md based on description

Done. Want to test it?

WAIT: Have a file to test this skill on?

USER: [Test or "looks good"]

ACTION: Test if requested

---

WAIT: Describe your second skill.

USER: [Description]

ACTION: Create skills/[skill-name].md

Done.

---

WAIT: Describe your third skill.

USER: [Description]

ACTION: Create skills/[skill-name].md

Done. You now have 3 custom skills.

---

ACTION: List all skills in the skills/ folder with descriptions

That's your skill library. Built by you, for your work.

These persist in this folder. Any time you want to use one, just tell me.

You can edit the skill files anytime to change behavior.

WAIT: Looking at all the skills you've built – which one will you use first in your real work?

USER: [Names a specific skill]

Good choice. That's your homework – actually use it this week.

---

**What you learned:** How to design custom skills for your specific workflows.

**What you built:** 3 personal skills tailored to your work.

**Key insight:** Skills grow with you. Start simple, refine over time.

**Next up:** The final lesson – what's next and dozens of things to try.

WAIT: Say "next lesson" to continue.

USER: Next lesson
