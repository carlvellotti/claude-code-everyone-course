# The Junior Employee Mental Model

The single most important mindset shift: Claude Code is a junior employee, not a magic wand.

Aakash Gupta said it best — "Delegate like you have 5 junior employees." You wouldn't dump a vague one-liner on a new hire and expect magic. You'd give them context, scope, and clear deliverables.

This maps directly to PM skills. Delegation, scope definition, and quality review ARE the PM skill set. We already know how to do this — we just need to apply it to AI.

The progression I've noticed:
1. Co-worker (you work alongside it)
2. Pair programmer (you guide, it types)
3. Team of agents (they run retrospectives and update their own instructions)

Related: [[Plan Mode]] is basically a design review for your AI. [[The Verification Loop]] is QA. These aren't new skills — they're PM skills applied to a new tool.

The "shoot and forget" principle from a practitioner I read: "Generally my goal is to delegate, set the context, and let it work. Judging the tool by the final PR and not how it gets there."

But this requires trust, and trust requires [[The Verification Loop]]. You can't shoot and forget until you've verified enough times to calibrate your expectations.

## What This Means for [[CLAUDE.md Best Practices]]

If Claude is a junior employee, then CLAUDE.md is the onboarding doc. You wouldn't onboard someone with a 50-page manual. You'd give them the essentials and let them ask questions.
