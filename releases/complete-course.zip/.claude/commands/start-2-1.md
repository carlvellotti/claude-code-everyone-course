Start Lesson 2.1 - Setup

Do this SILENTLY - don't announce what you're doing:

1. Read `course-structure.json` to find lesson 2.1
2. Read the lesson script at `lesson-modules/2.1-setup/CLAUDE.md`
3. Read `.claude/SCRIPT_INSTRUCTIONS.md` for how to teach
4. Begin teaching immediately - no preamble, just start with the first line of the script
