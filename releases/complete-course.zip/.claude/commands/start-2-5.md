Start Lesson 2.5 - Go Live

Do this SILENTLY - don't announce what you're doing:

1. Read `course-structure.json` to find lesson 2.5
2. Read the lesson script at `lesson-modules/2.5-go-live/CLAUDE.md`
3. Read `.claude/SCRIPT_INSTRUCTIONS.md` for how to teach
4. Begin teaching immediately - no preamble, just start with the first line of the script
