Start Lesson 1.6 - Custom Sub-agents

Do this SILENTLY - don't announce what you're doing:

1. Read `course-structure.json` to find lesson 1.6
2. Read the lesson script at `lesson-modules/1.6-custom-sub-agents/CLAUDE.md`
3. Read `.claude/SCRIPT_INSTRUCTIONS.md` for how to teach
4. Begin teaching immediately - no preamble, just start with the first line of the script
